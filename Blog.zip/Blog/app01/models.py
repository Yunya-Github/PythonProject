from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.


class UserInfo(AbstractUser):
    phone = models.BigIntegerField(verbose_name="手机号", null=True, blank=True)
    avatar = models.FileField(
        verbose_name="头像", upload_to='avatar/', default='avatar/default.png', max_length=64)
    # 默认头像
    create_time = models.DateField(
        verbose_name="注册时间", auto_now=False, auto_now_add=True)

    blog = models.OneToOneField(to="Blog", on_delete=models.CASCADE, null=True)

    def __str__(self):
        return "对象-%s" % self.username


class Blog(models.Model):
    site_name = models.CharField(verbose_name="站点名称", max_length=32)
    site_title = models.CharField(verbose_name="站点标题", max_length=32)
    site_theme = models.CharField(verbose_name="站点样式", max_length=64)

    def __str__(self):
        return "对象-%s" % self.site_title


class Category(models.Model):
    name = models.CharField(verbose_name="文章分类", max_length=32)
    blog = models.ForeignKey(to="Blog", on_delete=models.CASCADE, null=True)

    def __str__(self):
        return "对象-%s" % self.name


class Tag(models.Model):
    name = models.CharField(verbose_name="文章标签", max_length=32)
    blog = models.ForeignKey(to="Blog", on_delete=models.CASCADE, null=True)

    def __str__(self):
        return "对象-%s" % self.name


class Article2Tag(models.Model):
    article = models.ForeignKey(to="Article", on_delete=models.CASCADE)
    tag = models.ForeignKey(to="Tag", on_delete=models.CASCADE)


class Article(models.Model):
    title = models.CharField(verbose_name="文章标题", max_length=64)
    desc = models.CharField(verbose_name="文章简介", max_length=255)
    content = models.TextField(verbose_name="文章内容")
    create_time = models.DateField(
        verbose_name="创建时间", auto_now=False, auto_now_add=True)

    blog = models.ForeignKey(to="Blog", on_delete=models.CASCADE, null=True)
    category = models.ForeignKey(
        to="Category", on_delete=models.CASCADE, null=True)
    targs = models.ManyToManyField(
        to="Tag", through="Article2Tag", through_fields=("article", "tag"))

    # 优化
    up_num = models.BigIntegerField(verbose_name="点赞数", default=0)
    down_num = models.BigIntegerField(verbose_name="点踩数", default=0)
    comment_num = models.BigIntegerField(verbose_name="评论数", default=0)

    def __str__(self):
        return "对象-%s" % self.title


class UpAndDown(models.Model):
    user = models.ForeignKey(to="UserInfo")
    article = models.ForeignKey(to="Article")
    is_up = models.BooleanField()

    def __str__(self):
        return "对象-点赞点踩-%s" % self.user.username


class Comment(models.Model):
    user = models.ForeignKey("UserInfo", on_delete=models.CASCADE)
    article = models.ForeignKey("Article", on_delete=models.CASCADE)
    content = models.CharField(verbose_name="评论内容", max_length=255)
    comment_time = models.DateTimeField(
        verbose_name="评论时间", auto_now=True, auto_now_add=False)
    parent = models.ForeignKey(
        to="self", verbose_name="子评论", on_delete=models.CASCADE, null=True)  # null = True 针对根评论

    def __str__(self):
        return "对象-评论-%s" % self.user.username
