from django import template
from app01 import models
from django.db.models import Count
from django.db.models.functions import TruncMonth

register = template.Library()

# 自定义inclusion_tag


@register.inclusion_tag("left_menu.html")
def left_menu(username):
    # 侧边栏需要拿到blog，下拿到user_obj
    user_obj = models.UserInfo.objects.filter(username=username).first()
    blog = user_obj.blog

    # 分类、文章数
    category_list = models.Category.objects.filter(blog=blog).annotate(count_num=Count("article__pk")).values_list(
        "name", "count_num", "pk")
    # 标签、文章数
    tag_list = models.Tag.objects.filter(blog=blog).annotate(tag_num=Count("article__pk")).values_list("name",
                                                                                                       "tag_num", "pk")
    # 月份、文章数
    date_list = models.Article.objects.filter(blog=blog).annotate(month=TruncMonth("create_time")).values(
        "month").annotate(count_num=Count("pk")).values_list("month", "count_num")

    return locals()
