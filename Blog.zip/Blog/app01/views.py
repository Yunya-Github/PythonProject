from django.db import transaction
import random
from django.shortcuts import render
from django.shortcuts import redirect
from django.shortcuts import HttpResponse
from app01.myfroms import MyRegForm
from app01 import models
from django.http import JsonResponse
from django.contrib import auth
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO, StringIO
from django.contrib.auth.decorators import login_required
from django.db.models import Count
from django.db.models import F
from django.db.models.functions import TruncMonth
from utils.mypage import Pagination
import json
from bs4 import BeautifulSoup
import os
from Blog import settings

# Create your views here.


def register(request):
    form_obj = MyRegForm()
    if request.method == "POST":
        back_dic = {"code": 1000, "msg": ""}
        form_obj = MyRegForm(request.POST)
        if form_obj.is_valid():
            clean_data = form_obj.cleaned_data
            clean_data.pop("confirm_password")
            file_obj = request.FILES.get("avatar")
            # 判断是否传头像，如果没传头像就不添加存入字典
            
            if file_obj:
                clean_data["avatar"] = file_obj
                # 注意！用的auth组件，所以用create_user

            models.UserInfo.objects.create_user(**clean_data)
            back_dic["url"] = "/login"
        else:
            back_dic["code"] = 2000  # 验证不通过
            back_dic["msg"] = form_obj.errors

        return JsonResponse(back_dic)

    return render(request, "register.html", locals())


def login(request):
    if request.method == "POST":
        back_dic = {"code": 1000, "msg": ""}
        username = request.POST.get("username")
        password = request.POST.get("password")
        code = request.POST.get("code")
        # 校验验证码是否正确
        if request.session.get("code").upper() == code.upper():
            # 校验用户名和密码是否正确
            user_obj = auth.authenticate(
                request, username=username, password=password)
            if user_obj:
                auth.login(request, user_obj)
                back_dic["url"] = "/home/"  # 告诉页面，往这里跳

            else:
                back_dic["code"] = 2000
                back_dic["msg"] = "用户名错误或密码错误"
        else:
            back_dic["code"] = 3000
            back_dic["msg"] = "验证码错误"

        return JsonResponse(back_dic)

    return render(request, "login.html")


def home(request):
    count = range(0, 20)
    article_queryset = models.Article.objects.all()
    return render(request, "home.html", locals())


@login_required
def set_password(request):
    if request.is_ajax():
        back_dic = {"code": 1000, "msg": ""}
        if request.method == "POST":
            old_password = request.POST.get("old_password")
            new_password = request.POST.get("new_password")
            confirm_password = request.POST.get("confirm_password")
            is_right = request.user.check_password(old_password)

            if is_right:
                if new_password == confirm_password:
                    request.user.set_password(new_password)
                    request.user.save()
                    back_dic["msg"] = "修改成功"
                else:
                    back_dic["code"] = 1001
                    back_dic["msg"] = "两次密码不一致"

            else:
                back_dic["code"] = 1002
                back_dic["msg"] = "原密码错误"
    return JsonResponse(back_dic)


@login_required
def logout(request):
    auth.logout(request)
    return redirect("/home/")


def site(request, username, **kwargs):
    # kwargs有值就是额外筛选

    # 校验用户是否存在，用户存在站点就存在
    user_obj = models.UserInfo.objects.filter(username=username).first()
    if not user_obj:
        # 返回404页面
        return render(request, "errors.html")
    blog = user_obj.blog
    # 查询所有文章
    article_queryset = models.Article.objects.filter(blog=blog)

    if kwargs:
        condition = kwargs.get("condition")
        param = kwargs.get("param")
        # 判断用户筛选条件（分类、标签、日期）
        if condition == "category":

            article_queryset = article_queryset.filter(category_id=param)

        elif condition == "tag":
            article_queryset = article_queryset.filter(targs__id=param)

        else:
            year, month = param.split("-")
            article_queryset = article_queryset.filter(
                create_time__year=year, create_time__month=month)

    # 分类、文章数
    category_list = models.Category.objects.filter(blog=blog).annotate(count_num=Count("article__pk")).values_list(
        "name", "count_num", "pk")
    # 标签、文章数
    tag_list = models.Tag.objects.filter(blog=blog).annotate(tag_num=Count("article__pk")).values_list("name",
                                                                                                       "tag_num", "pk")
    # 月份、文章数
    date_list = models.Article.objects.filter(blog=blog).annotate(month=TruncMonth("create_time")).values(
        "month").annotate(count_num=Count("pk")).values_list("month", "count_num")

    return render(request, "site.html", locals())


def article_detail(request, username, article_id):
    article_obj = models.Article.objects.filter(
        pk=article_id, blog__userinfo__username=username).first()
    user_obj = models.UserInfo.objects.filter(username=username).first()
    blog = user_obj.blog
    if not article_obj:
        return render(request, "errors.html")
    # 获取全部评论
    comment_list = models.Comment.objects.filter(article=article_obj)
    return render(request, "article_detail.html", locals())


def up_or_down(request):
    # 1.校验用户是否登录
    # 2.判断文章是否自己写的，自己不能点自己的
    # 3.当前用户是否已经给当前文章点过赞/踩了，点过之后不允许再点
    if request.is_ajax():
        back_dic = {"code": 1000, "msg": ""}
        # 判断用户是否登录
        if request.user.is_authenticated():
            article_id = request.POST.get("article_id")
            is_up = json.loads(request.POST.get("is_up"))  # 字符串 true 转换为 True
            # 判断是否自己写的文章 根据文章ID查询文章对象然后根据文章对象查作者，和request.user比对是否是用户自身
            article_obj = models.Article.objects.filter(pk=article_id).first()
            if not article_obj.blog.userinfo == request.user:
                # 校验是否点过
                is_click = models.UpAndDown.objects.filter(
                    user=request.user, article=article_obj)
                if not is_click:  # 没点过
                    # 判断是赞还是踩
                    if is_up:
                        # 点赞数+1
                        models.Article.objects.filter(
                            pk=article_id).update(up_num=F("up_num")+1)
                        back_dic["msg"] = "点赞成功"
                    else:
                        # 点踩数+1
                        models.Article.objects.filter(
                            pk=article_id).update(down_num=F("down_num")-1)

                    # 操纵点赞点踩
                    models.UpAndDown.objects.create(
                        user=request.user,
                        article=article_obj,
                        is_up=is_up,
                    )
                else:
                    back_dic["code"] = 1001
                    back_dic["msg"] = "你已经点过了，不要再点了"
            else:
                back_dic["code"] = 1002
                back_dic["msg"] = "不能给自己文章点赞/踩"
        else:
            back_dic["code"] = 1003
            back_dic["msg"] = "请先<a href='/login/'>登录</a>"

        return JsonResponse(back_dic)


def comment(request):
    if request.is_ajax():
        back_dic = {"code": 1000, "msg": ""}
        if request.method == "POST":
            # 判断是否登录
            if request.user.is_authenticated():
                article_id = request.POST.get("article_id")
                content = request.POST.get("comment")
                parent_id = request.POST.get("parent_id")
                # 两张表，article普通字段，Comment表
                with transaction.atomic(): # 开启事务
                    models.Article.objects.filter(pk=article_id).update(
                        comment_num=F("comment_num")+1)
                    models.Comment.objects.create(user=request.user,article_id=article_id,content=content,parent_id=parent_id)
                back_dic["msg"] = "评论成功"
            else:
                back_dic["code"] = 1001
                back_dic["msg"] = "用户未登录"
        return JsonResponse(back_dic)


@login_required
def backend(request):
    article_list = models.Article.objects.filter(blog=request.user.blog)
    page_obj = Pagination(
        currentPage=request.GET.get("p",1),
        totalCount=article_list.count(),
    )
    page_queryset = article_list[page_obj.start:page_obj.end]
    return render(request,"backend/backend.html",locals())

@login_required
def add_article(request):
    if request.method == "POST":
        title = request.POST.get("title")
        content = request.POST.get("content")
        category_id = request.POST.get("category")
        tag_id_list = request.POST.getlist("tag")
        # 防止xss攻击
        soup = BeautifulSoup(content,"html.parser")
        # 获取所有标签、删除掉script
        tags = soup.find_all()
        for tag in tags:
            if tag.name == "script":
                tag.decompaose()

        # 差一个文章简介，用content中一百50个字符 targs
        desc = soup.text[0:150]
        article_obj = models.Article.objects.create(
            title=title,
            content=str(soup),
            desc=desc,
            category_id=category_id,
            blog=request.user.blog,
        )
        # 文章标签关系表，无法使用add，remove，set，clear
        article_obj_list = []
        for i in tag_id_list:
            # 生成对象，放进列表
            article_obj_list.append(models.Article2Tag(
                article=article_obj,
                tag_id=i,
            ))
        # 批量插入
        # models.Article2Tag.objects.bulk_create(article_obj_list)
        # 跳转后台管理文章展示页
        return redirect("/backend/")

    category_list = models.Category.objects.filter(blog=request.user.blog)
    tag_list = models.Tag.objects.filter(blog=request.user.blog)
    return render(request,"backend/add_article.html",locals())


@login_required
def upload_img(request):
    if request.method == "POST":
        # error 0 成功 1 失败
        back_dic = {"error":0,"message":""}
        file_obj = request.FILES.get("imgFile") # 默认的图片名称

        file_dir = os.path.join(settings.BASE_DIR,"media","article_img")
        # 如文件夹不存在，则创建
        if not os.path.isdir(file_dir):
            os.mkdir(file_dir)
        # 拼接图片完整路径(可以用uuid做唯一拼接)
        file_path = os.path.join(file_dir,file_obj.name)
        with open(file_path,"wb") as f:
            for line in file_obj:
                f.write(line)
        # 拼接返回的路径
        back_dic["url"] = '/media/article_img/%s'%file_obj.name


    return JsonResponse(back_dic)


@login_required
def set_avater(request):

    if request.method == "POST":
        file_obj = request.FILES.get("avatar")
        # 这样才可以自动添加 /avatar 的前缀
        user_obj = request.user
        user_obj.avatar = file_obj
        user_obj.save()

    blog = request.user.blog
    username = request.user.username

    return render(request,"set_avater.html",locals())

def get_random():
    return random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)


def get_code(request):
    # 生成图片 颜色模式，尺寸，颜色(3原色，单词)
    img_obj = Image.new("RGB", (430, 35), get_random())
    # 产生画笔对象
    img_draw = ImageDraw.Draw(img_obj)
    # 字体样式，字体大小
    img_font = ImageFont.truetype("static/font/karen-2.otf", 30)
    # 生成随机验证码
    code = ""
    for i in range(5):
        random_upper = chr(random.randint(65, 90))  # 随机大写
        random_lower = chr(random.randint(97, 122))  # 随机小写
        random_int = str(random.randint(0, 9))  # 随机数字
        temp = random.choice(
            [random_lower, random_upper, random_int])  # 随机取出一个
        # 写code到图片上，一个一个写，隔开距离
        img_draw.text((i * 60 + 80, 0), temp, get_random(),
                      img_font)  # 写入位置(X,Y)、写入字符
        # 拼接随机字符串
        code += temp
    print(code)
    request.session['code'] = code  # 存入session中

    io_obj = BytesIO()  # 生成内存管理器对象，看成文件句柄即可
    img_obj.save(io_obj, "png")  # 图片写入内存
    get_img = io_obj.getvalue()  # 读取图片(二进制)

    return HttpResponse(get_img)
