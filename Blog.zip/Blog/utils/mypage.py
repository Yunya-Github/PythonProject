
class Pagination(object):
    """通用分页组件"""

    def __init__(self, totalCount, currentPage, perPageNum=10, maxPageNum=7,):
        self.total_count = totalCount  # 数据总个数  0
        try:
            self.current_page = int(currentPage)  # 当前页  1
        except Exception as e:
            self.current_page = 1
        if self.current_page <= 0:
            self.current_page = 1
        self.per_page_item_num = perPageNum  # 每页显示的行数
        self.max_page_num = maxPageNum  # 按钮数量

    @property
    def start(self):
        return (self.current_page - 1) * self.per_page_item_num  # 0

    @property
    def end(self):
        return self.current_page * self.per_page_item_num  # 0

    @property
    def num_pages(self):
        '''总页数'''
        a, b = divmod(self.total_count, self.per_page_item_num)
        if not b:  # 如果存在多余的数据则多加一页页数
            return a
        return a + 1

    def pager_num_range(self):

        if self.num_pages < self.max_page_num:
            return range(1, self.num_pages + 1)  # range不取后面的值，所以+1
        '''下面是数据足够多的情况下'''
        part = int(self.max_page_num / 2)  # 拿到一半的数据。

        if self.current_page <= part:
            return range(1, self.max_page_num + 1)  # 动态效果

        if (self.current_page + part) >= self.num_pages:
            return range(self.num_pages - self.max_page_num + 1,self.num_pages + 1)

        return range(self.current_page - part, self.current_page + part + 1)

    def page_str(self):
        """该方法用于在插件中自动生成页码按钮"""
        page_list = []
        first_1 = '<ul class="pagination">'
        if self.total_count == 0:
            first = '<li class="disabled"><a>首页</a></li>'
        else:
            first = '<li><a href="?p=1">首页</a></li>'
        page_list.append(first_1)
        page_list.append(first)

        # ---------------上一页---------------------#
        if self.current_page == 1 or self.total_count == 0:
            prev = '<li class="disabled"><a>上一页</a></li>'
        else:
            # Pyhon3.8新增f语句格式化字符串
            # -1
            prev = f'<li><a href="?p={self.current_page - 1}">上一页</a></li>'
        page_list.append(prev)

        # ---------------数据与当前页样式---------------------#
        for i in self.pager_num_range():
            if i == self.current_page:
                temp = f'<li class="active" ><a href="?p={i}">{i}</a></li>'
            else:
                temp = f'<li ><a href="?p={i}">{i}</a></li>'
            page_list.append(temp)
        # ---------------下一页---------------------#
        if self.current_page == self.num_pages or self.total_count == 0:
            nex_t = '<li class="disabled" ><a>下一页</a></li>'
        else:
            nex_t = f'<li><a href="?p={self.current_page + 1}">下一页</a></li>'
        page_list.append(nex_t)
        if self.total_count == 0:
            last = f'<li  class="disabled" ><a>尾页</a></li>'
        else:
            last = f'<li><a href="?p={self.num_pages}">尾页</a></li>'
        page_list.append(last)
        last_1 = "</ul>"
        page_list.append(last_1)

        return ' '.join(page_list)
